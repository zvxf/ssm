package ssm.web;


public class BaseController {
}
