package ssm.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import ssm.service.impl.ArticleServiceImpl;

@Controller
public class HomeController extends BaseController {
    @Autowired
    private ArticleServiceImpl articleServiceImpl;
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public String home(Model model){
        model.addAttribute("article",articleServiceImpl.selectArticleList());
        return "home";
    }
    @RequestMapping("/article") //article?page=
    public String article(Model model,@RequestParam(value = "page")int page){

        model.addAttribute("article",articleServiceImpl.selectArticle(page));
        return "article/article";
    }
}
