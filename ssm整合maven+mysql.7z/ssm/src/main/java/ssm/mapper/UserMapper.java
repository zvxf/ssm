package ssm.mapper;

import ssm.model.User;

import java.util.List;

public interface UserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

    List<User> insertUserList(List<User> userList);

    List<User> deleteUserList(List<User> userList);

    List<User> updateUserList(List<User> userList);

    List<User> selectUserList();




}