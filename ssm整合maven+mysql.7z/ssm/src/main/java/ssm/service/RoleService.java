package ssm.service;

import ssm.model.Role;

import java.util.List;

public interface RoleService {
    int insertRole(Role role);
    int deleteRole(int id);
    int updateRole(Role role);
    Role selectRole(int id);
    List<Role> selectRoleList();
}
