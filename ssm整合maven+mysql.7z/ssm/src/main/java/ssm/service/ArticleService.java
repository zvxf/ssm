package ssm.service;

import ssm.model.Article;

import java.util.List;

public interface ArticleService {
    int insertArticle(Article article);
    int delectArticle(int id);
    int updateArticle(Article article);
    Article selectArticle(int id);
    List<Article> selectArticleList();
}
