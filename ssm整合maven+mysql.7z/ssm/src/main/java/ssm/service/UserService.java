package ssm.service;

import ssm.model.User;

import java.util.List;

public interface UserService {
    int insertUser(User user) throws Exception;
    int deleteUser(int id)throws Exception;
    int updateUser(User user)throws Exception;
    User selectUser(int id)throws Exception;
    List<User> selectUserList(User user);
}
