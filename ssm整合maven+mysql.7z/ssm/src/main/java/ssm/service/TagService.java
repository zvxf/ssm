package ssm.service;

import ssm.model.Tag;


public interface TagService {
    int insertTag(Tag tag);
    int deleteTag(int id);
    int updateTag(Tag tag);
    Tag selectTag(int id);
}
