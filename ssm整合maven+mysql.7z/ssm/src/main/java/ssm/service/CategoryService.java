package ssm.service;

import ssm.model.Category;

public interface CategoryService {
    int insertCategory(Category category);
    int delectCategory(int id);
    int updateCategory(Category category);
    Category selectCategory(int id);
}
