package ssm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ssm.mapper.UserMapper;
import ssm.model.User;
import ssm.service.UserService;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Override
    public int insertUser(User user) {
        userMapper.insert(user);
        return 0;
    }

    @Override
    public int deleteUser(int id) {
        userMapper.deleteByPrimaryKey(id);
        return 0;
    }

    @Override
    public int updateUser(User user) {
        userMapper.updateByPrimaryKey(user);
        return 0;
    }

    @Override
    public User selectUser(int id) {
        return userMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<User> selectUserList(User user) {
        return userMapper.selectUserList();
    }

    public int registerUser(User user){
        return userMapper.insert(user);
    }
    public int loginUser(String username,String password){
        User user = new User();

        return 0;
    }
}
