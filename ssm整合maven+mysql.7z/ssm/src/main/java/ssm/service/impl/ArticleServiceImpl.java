package ssm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ssm.mapper.ArticleMapper;
import ssm.model.Article;
import ssm.service.ArticleService;

import java.util.List;

@Service
public class ArticleServiceImpl implements ArticleService {
    @Autowired
    private ArticleMapper articleMapper;
    @Override
    public int insertArticle(Article article) {
        articleMapper.insert(article);
        return 0;
    }

    @Override
    public int delectArticle(int id) {
        articleMapper.deleteByPrimaryKey(id);
        return 0;
    }

    @Override
    public int updateArticle(Article article) {
        articleMapper.updateByPrimaryKey(article);
        return 0;
    }

    @Override
    public Article selectArticle(int id) {
        return articleMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Article> selectArticleList() {
        return articleMapper.selectArticleList();
    }
}
