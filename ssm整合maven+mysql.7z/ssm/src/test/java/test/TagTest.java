package test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ssm.mapper.TagMapper;
import ssm.model.Tag;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:springAppContext.xml"})
public class TagTest {

    @Autowired
    private TagMapper tagMapper;
    @Test
    public void tag(){
        Tag tag = tagMapper.selectByPrimaryKey(3);
        System.out.print(tag.getName());

    }

}
