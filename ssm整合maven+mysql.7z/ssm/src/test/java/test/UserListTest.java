package test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ssm.mapper.UserMapper;
import ssm.model.Tag;
import ssm.model.User;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:springAppContext.xml"})
public class UserListTest {
    @Autowired
    private UserMapper userMapper;
    @Test
    public void list(){
        List<User> userList = userMapper.selectUserList();
        for (User u:userList){
            System.out.println(u.getNickname());

        }

    }
}
